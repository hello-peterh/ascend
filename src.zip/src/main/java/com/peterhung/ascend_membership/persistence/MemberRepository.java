package com.peterhung.ascend_membership.persistence;

import com.peterhung.ascend_membership.Entity.Member;
//
//import java.util.Arrays;
//import java.util.Collection;
//
//import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;
//
//import java.util.Collection;
//import java.util.HashMap;
//import java.util.Map;

public interface MemberRepository extends CrudRepository<Member, Long> {

//    private static Map<Integer, Member> members;
//
//    static {
//
//        members = new HashMap<Integer, Member>() {
//
//            {
//                put(1, new Member (1, "Elon", "Musk", "123 Test St", "Caucasian", new String[]{"Programming","Computer Science"}));
//                put(2, new Member (2, "Steve", "Jobs", "123 Test St", "Caucasian", new String[]{"Design","Computers"}));
//                put(3, new Member (3, "Mark", "Zucc", "123 Test St", "Caucasian", new String[]{"Data Science","Data"}));
//            }
//        };
//    }

//    public Collection<Member> getAllMembers() {
//        return this.members.values();
//    }
//
//    public Member getMemberById(int id) {
//        return this.members.get(id);
//    }
//
//    public void removeMemberById(int id) {
//        this.members.remove(id);
//    }
//
//    public void updateMember(Member member) {
//        Member m = members.get(member.getId());
//        m.setFirstName(member.getFirstName());
//        m.setLastName(member.getLastName());
//        m.setAddress(member.getAddress());
//        m.setEthnicity(member.getEthnicity());
//        m.setInterests(member.getInterests());
//
//        members.put(member.getId(), member);
//    }
//
//    public void insertMemberToDb(Member member) {
//        this.members.put(member.getId(), member);
//    }
}
